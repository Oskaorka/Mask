// управление корзиной
$(document).ready(function(){
	$(function () {
		$('.smart-basket__wrapper').smbasket({
			productElement: 'product__element',
			buttonAddToBasket: 'product__add-to-cart-button',
			countryCode: '+7',
            smartBasketCurrency: '₽',
            productPrice: 'product__price-number',
            productSize: 'product__size',
			productQuantityWrapper: 'product__quantity',
			smartBasketMinArea: 'header__basket-min',
			smartBasketMinText: 'ЗАКАЗАТЬ',
            smartBasketMinIconPath: 'wp-content/themes/childhood/assets/img/favicons/shopping-basket-wight.svg',
            

			telIsRequired: false,
			emailIsRequired: true,
			textArea:{
				isRequired: false,
			},
			agreement: {
			isRequired: true,
			isChecked: true,
			isLink: 'https://веб-дизайнер51.рус/policy/',
			} 
		});
		 
		});
	// $('.carousel__inner').slick({
	// 	speed: 1200,
	// 	/*adaptiveHeight: true,*/
	// 	prevArrow: "<button type='button' class='slick-prev'><img src='img/right.png'></button>",
	// 	nextArrow: '<button type="button" class="slick-next"><img src="img/left.png"></button>',
	// 	responsive: [
	// 		{
	// 			breakpoint: 992,
  	// 			settings: {
	// 				dots: true,
	// 				arrows: false
	// 			}	
	// 		}
	// 	]
    // });
    
// здесь табы каталога
	$('ul.catalog__tabs').on('click', 'li:not(.catalog__tab_active)', function() {
        $(this)
          .addClass('catalog__tab_active').siblings().removeClass('catalog__tab_active')
		  .closest('div.container').find('div.catalog__content').removeClass('catalog__content_active')
		  .eq($(this).index()).addClass('catalog__content_active');
    });

    function toggleSlide(item) {
        $(item).each(function(i) {
            $(this).on('click', function(e) {
                e.preventDefault();
                $('.catalog-item__content').eq(i).toggleClass('catalog-item__content_active');
                $('.catalog-item__list').eq(i).toggleClass('catalog-item__list_active');
            });
        });
    }

    toggleSlide('.catalog-item__link');
	toggleSlide('.catalog-item__back');
	
	//modal window
	// $('[data-modal=consultation]').on('click', function() {
    //     $('.overlay, #consultation').fadeIn('slow');
    // });
    // $('.modal__close').on('click', function() {
    //     $('.overlay, #consultation, #thanks, #order').fadeOut('slow');
	// });
	// $('.button_mini').each(function(i) {
    //     $(this).on('click', function() {
    //         $('#order .modal__descr').text($('.catalog-item__subtitle').eq(i).text());
    //         $('.overlay, #order').fadeIn('slow');
    //     });
	// });
	
	// $('form').submit(function(e) {
	// 	e.preventDefault();
	// 	$.ajax({
	// 		type:"POST",
	// 		url: "mailer/smart.php",
	// 		data: $(this).serialize()
	// 	}).done(function() {
	// 		$(this).find("input").val("");
	// 		$('#consultation, #order').fadeOut();
	// 		$('.overlay,#thanks').fadeIn('slow');

	// 		$('form').trigger('reset');
	// 	});
	// 	return false;
	// });


	//Smooth scroll and pageup

// 	$(window).scroll(function() {
// 		if ($(this).scrollTop() > 1600) {
// 			$('.pageup').fadeIn();
// 		} else {
// 			$('.pageup').fadeOut();
// 		}

// 	});

// 	$("a[href=#]").click(function(){
// 		const _href = $(this).attr("href");
// 		$("html, body").animate({scrollTop: $(_href).offset().top+"px"});
// 		return false;
//   });
// скрипт для видео
function addVideosToPage(videoWrapperClass, linkClass, imageClass, buttonClass, enabledClass){
    function findVideos() {
        //take all videos
        let videos = document.querySelectorAll(videoWrapperClass);
        //run functions for each video on the page
        for (let i = 0; i < videos.length; i++) {
            setupVideo(videos[i]);
        }
    }

    function setupVideo(video) {
        //link to video
        let link = video.querySelector(linkClass);
        //video preview
        let media = video.querySelector(imageClass);
        //play button
        let button = video.querySelector(buttonClass);
        //parse id of video from url of image in current videowrapper
        let id = parseMediaURL(link);
        

        //add creating iframe instead of videolink by clicking videowrapper
        video.addEventListener('click', () => {
            //create iframe
            let iframe = createIframe(id);
            //revome link
            link.remove();
            //remove button
            button.remove();
            //place iframe inside the videowrapper
            video.appendChild(iframe);
        });

        //remove href from link to make the link just as container
        link.removeAttribute('href');
        //add class that shows our youtube button
        video.classList.add(enabledClass.replace('.', ''));
    }
     function parseMediaURL(link) {
            let regexp = /youtu\.be\/([a-zA-Z0-9_-]+)/i;
            let url = link.href;
            let match = url.match(regexp);
            return match[1];
        }
    //creating iframe
    function createIframe(id) {
        let iframe = document.createElement('iframe');
        iframe.setAttribute('allowfullscreen', '');
        iframe.setAttribute('allow', 'autoplay');
        iframe.setAttribute('src', generateURL(id));
        iframe.classList.add(imageClass.replace('.', ''));
        return iframe;
    }
    //generating url for iframe
    function generateURL(id)  {
        let query = '?rel=0&showinfo=0&autoplay=1';

        return ('https://www.youtube.com/embed/') + id + query;
    }

    findVideos();
}

addVideosToPage('.video', '.video__link', '.video__media', '.video__button', '.video--enabled');

//конец скрипта для видео

});

// let popup = document.querySelector('.smart-basket_active'),
//     // popupToggle = document.querySelector('smart-basket__min'),
//     popupClose = document.querySelector('.smart-basket__close-form');

//     // popupToggle.onclick = function() {
//     //     popup.style.display="block";
//     // }

//     popupClose.onclick = function () {
//         popup.style.display ="none";

// }


// window.onclick = function (e) {
//   if(e.target == popup) {
//     popup.style.display ="none";
//   } else {
//     document.querySelector('.smart-basket_active') = style.display ="none";
//   }
// }
// var currentSlide = $('.carousel__inner').slick('slickCurrentSlide');
// $(document).ready(function(){
//     $('.carousel__inner').slick({
//          speed: 1200,
//          slidesToShow: 3,
//          /*adaptiveHeight: true,*/
//          prevArrow:  '<button class="slide__arrow--right"><svg width="15" height="25" viewBox="0 0 15 25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.0171 11.6077L2.77467 0.369029C2.28137 -0.123032 1.48213 -0.123032 0.987571 0.369029C0.494263 0.861093 0.494264 1.66033 0.987572 2.15239L11.3382 12.4993L0.98882 22.8462C0.495512 23.3383 0.495512 24.1375 0.98882 24.6308C1.48213 25.1229 2.28261 25.1229 2.77592 24.6308L14.0183 13.3923C14.504 12.9053 14.504 12.0935 14.0171 11.6077Z" fill="white"/></svg></button>',
//          nextArrow: '<button class="slide__arrow--left"><svg width="15" height="25" viewBox="0 0 15 25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.982942 13.3923L12.2253 24.631C12.7186 25.123 13.5179 25.123 14.0124 24.631C14.5057 24.1389 14.5057 23.3397 14.0124 22.8476L3.66178 12.5007L14.0112 2.15378C14.5045 1.66172 14.5045 0.862477 14.0112 0.369169C13.5179 -0.122894 12.7174 -0.122894 12.2241 0.369169L0.981696 11.6077C0.495966 12.0947 0.495966 12.9065 0.982942 13.3923Z" fill="white"/></svg></button>',
//          responsive: [
//              {
//                  breakpoint: 992,
//                    settings: {
//                     slidesToShow: 1,
//                      dots: false,
//                      arrows: true
//                  }	
//              }
//          ]
//      });
//  });

const slider = tns({
    container: '.carousel__inner',
    slideBy: 'page',
    autoplay: false,
    controls: false,
    nav: false,
    items: 1,
    responsive: {
        320: {
          items: 1 
        },
        640: {
          edgePadding: 20,
          gutter: 20,
          items: 1
        },
        700: {
          gutter: 30
        },
        900: {
          items: 2
        },
        1200: {
          items: 3
        }
      }

});

document.querySelector('.prev').addEventListener('click', function () {
    slider.goTo('prev');
  });
  document.querySelector('.next').addEventListener('click', function () {
    slider.goTo('next');
  });  





    



