<?php
    require_once($_SERVER['DOCUMENT_ROOT'] . '/smartbasket/php/phpmailer.php');

		// *** SMTP *** //

		 require_once($_SERVER['DOCUMENT_ROOT'] . '/smartbasket/php/smtp.php');
		 const HOST = 'smtp.mail.ru';
		 const LOGIN = 'oskaorka@mail.ru';
		 const PASS = 'Q17198511kos11';
		 const PORT = '465';

		// *** /SMTP *** //
   
    const SENDER = 'oskaorka@mail.ru';
    const CATCHER = 'oskaorka171985@yandex.ru';
    const SUBJECT = 'Заявка с сайта LOLO';
	const CHARSET = 'UTF-8';
	



	
    