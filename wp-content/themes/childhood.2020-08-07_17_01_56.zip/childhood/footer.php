

		<!-- <div class="question">


			<div class="question__close">&times</div>
		</div> -->
		
<div class="reply">
	<div class="reply__body">
		<div class="reply__title">
			Заполните поля, мы вам перезвоним
		</div>
		<?php echo do_shortcode('[contact-form-7 id="660" title="Форма заявки обратной связи"]'); ?>
		<!-- <p><input type="checkbox" name="option1" value="a1" checked></p> -->
	</div>
	
</div>
<footer style="
			<?php
				$field = get_field('header_color');
				if ($field == 'Wheat') {
					?>
					background: #F5DEB3;
					<?php
				}
				if ($field == 'Lavanda') {
					?>
					background: #e6e6fa;
					<?php
				} 
				if ($field == 'GreenYellow') {
					?>
					background: #c0f2c0;
					<?php
				}
			?>
				max-width: 100%;padding: 0% 5%;"
			>
	<div class="container container-footer">
		<div class="row align-items-center">
			<!-- <div class="col-lg-2"> -->
				<div class="footer__logo">
					<?php the_custom_logo(); ?>
				</div>
			<!-- </div> -->
			<!-- <diva class="col-md-8 offset-md-0 col-lg-6 col-xl-5 offset-xl-1"> -->
				<div class="footer__contacts">
				
					<div class="footer__contacts-item">
						<!-- <img src="<?php echo bloginfo('template_url');?>/assets/img/icons/svg/pointer.svg" alt="указатель" class="footer__contacts-logo"> -->
						<address><?php the_field('adres'); ?></address>
					</div>
					<div class="footer__contacts-item">
						<img src="<?php echo bloginfo('template_url');?>/assets/img/icons/svg/phone.svg" alt="телефон" class="footer__contacts-logo">
						<div class="footer__contacts-tel">
							<a href="tel:+797867834347"><?php the_field('phone', 2); ?></a>
							<a href="tel:+797867834358"><?php the_field('phone-2', 2); ?></a>
						</div>
					</div>
					<div class="footer__contacts-item">
						<img src="<?php echo bloginfo('template_url');?>/assets/img/icons/svg/email.svg" alt="почта" class="header__contacts-logo">
						<a href="<?php the_field('mail', 2); ?>" class="header__contacts-mail"><?php the_field('mail', 2); ?></a>
					</div>
				
			<!-- </diva>		 -->
			</div>
			<!-- <diva class="col-md-4 col-lg-3"> -->
				<div class="footer__social">
					<!-- <div class="footer__social-item">
					Мы в соцсетях:
					</div> -->
					<a href="<?php the_field('instagram', 2); ?>" class="footer__social-item">
						<svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M16.0959 0.442627H6.40873C3.11902 0.442627 0.442627 3.11915 0.442627 6.40885V16.096C0.442627 19.3858 3.11902 22.0622 6.40873 22.0622H16.0959C19.3858 22.0622 22.0622 19.3857 22.0622 16.096V6.40885C22.0624 3.11915 19.3858 0.442627 16.0959 0.442627ZM20.1442 16.096C20.1442 18.3281 18.3281 20.144 16.096 20.144H6.40873C4.17671 20.1442 2.36082 18.3281 2.36082 16.096V6.40885C2.36082 4.17684 4.17671 2.36082 6.40873 2.36082H16.0959C18.328 2.36082 20.144 4.17684 20.144 6.40885V16.096H20.1442Z" fill="white"/>
							<path d="M11.2525 5.68188C8.18067 5.68188 5.68164 8.18091 5.68164 11.2527C5.68164 14.3244 8.18067 16.8233 11.2525 16.8233C14.3243 16.8233 16.8233 14.3244 16.8233 11.2527C16.8233 8.18091 14.3243 5.68188 11.2525 5.68188ZM11.2525 14.905C9.23849 14.905 7.59984 13.2666 7.59984 11.2526C7.59984 9.23847 9.23836 7.59995 11.2525 7.59995C13.2666 7.59995 14.9051 9.23847 14.9051 11.2526C14.9051 13.2666 13.2664 14.905 11.2525 14.905Z" fill="white"/>
							<path d="M17.0568 4.0553C16.6873 4.0553 16.3242 4.20492 16.0632 4.46707C15.8009 4.72795 15.6501 5.09112 15.6501 5.46198C15.6501 5.83168 15.801 6.19473 16.0632 6.45688C16.3241 6.71775 16.6873 6.86865 17.0568 6.86865C17.4277 6.86865 17.7896 6.71775 18.0517 6.45688C18.3139 6.19473 18.4635 5.83155 18.4635 5.46198C18.4635 5.09112 18.3139 4.72795 18.0517 4.46707C17.7909 4.20492 17.4277 4.0553 17.0568 4.0553Z" fill="white"/>
						</svg>
					</a>
					<a href="<?php the_field('facebook', 2); ?>" class="footer__social-item">
						<svg width="13" height="24" viewBox="0 0 13 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M12.0252 0.237307L9.05681 0.232544C5.72194 0.232544 3.5668 2.44365 3.5668 5.86592V8.46328H0.582228C0.324325 8.46328 0.115479 8.67236 0.115479 8.93026V12.6935C0.115479 12.9514 0.324563 13.1603 0.582228 13.1603H3.5668V22.6562C3.5668 22.9142 3.77565 23.123 4.03355 23.123H7.92757C8.18547 23.123 8.39432 22.9139 8.39432 22.6562V13.1603H11.884C12.1419 13.1603 12.3507 12.9514 12.3507 12.6935L12.3522 8.93026C12.3522 8.80643 12.3029 8.68784 12.2155 8.60021C12.1281 8.51257 12.009 8.46328 11.8852 8.46328H8.39432V6.26146C8.39432 5.20318 8.6465 4.66594 10.0251 4.66594L12.0247 4.66523C12.2824 4.66523 12.4912 4.45614 12.4912 4.19848V0.704055C12.4912 0.446629 12.2826 0.237783 12.0252 0.237307Z" fill="white"/>
						</svg>
					</a>
					<a href="<?php the_field('twitter', 2); ?>" class="footer__social-item" >
						<svg width="23" height="34" viewBox="328 355 335 276" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M 630, 425A 195, 195 0 0 1 331, 600A 142, 142 0 0 0 428, 570A  70,  70 0 0 1 370, 523A  70,  70 0 0 0 401, 521A  70,  70 0 0 1 344, 455A  70,  70 0 0 0 372, 460A  70,  70 0 0 1 354, 370A 195, 195 0 0 0 495, 442A  67,  67 0 0 1 611, 380A 117, 117 0 0 0 654, 363A  65,  65 0 0 1 623, 401A 117, 117 0 0 0 662, 390A  65,  65 0 0 1 630, 425Z"
							style="fill:#fff;"/>
						</svg>
					</a>
					<a href="<?php the_field('vkontakte', 2); ?>" class="footer__social-item">
						<svg height="30px"  viewBox="0 0 512 512" width="32px"  xmlns="http://www.w3.org/2000/svg">
						<path d="M475.515,137.899c3.16-10.674,0-18.53-15.2-18.53h-50.297c-12.809,0-18.702,6.746-21.861,14.261    c0,0-25.617,62.422-61.825,102.899c-11.698,11.699-17.078,15.457-23.482,15.457c-3.158,0-8.027-3.758-8.027-14.432v-99.655    c0-12.809-3.588-18.53-14.176-18.53h-79.075c-8.027,0-12.809,5.978-12.809,11.528c0,12.125,18.104,14.943,19.983,49.101v74.123    c0,16.225-2.904,19.212-9.308,19.212c-17.079,0-58.581-62.678-83.174-134.409c-4.952-13.919-9.821-19.555-22.715-19.555H43.25    c-14.346,0-17.25,6.746-17.25,14.261c0,13.32,17.079,79.502,79.502,166.945c41.587,59.689,100.167,92.056,153.453,92.056    c32.022,0,35.951-7.173,35.951-19.555c0-57.045-2.903-62.425,13.152-62.425c7.428,0,20.237,3.757,50.127,32.534    c34.155,34.158,39.792,49.445,58.92,49.445h50.297c14.347,0,21.606-7.173,17.421-21.351    c-9.564-29.801-74.208-91.114-77.111-95.213c-7.429-9.564-5.295-13.835,0-22.375C407.799,253.608,469.195,167.189,475.515,137.899    L475.515,137.899z" style="fill:#fff;"/>
						</svg>
					</a>
				</div>
				
			<!-- </diva> -->
		
		<!-- <div class="row"> -->
			<!-- <diva class="col-12"> -->
				<div class="foot__menu">
				<?php
								wp_nav_menu( [
					'menu'            => 'foot', 
					'container'       => 'false', 
					'menu_class'      => 'policy', 
					'echo'            => true,
					'fallback_cb'     => 'wp_page_menu',
					'items_wrap'      => '<ul class="policy">%3$s</ul>',
					'depth'           => 1,
					] );
					
					?>
				<!-- <a href="news" class="news">новости о covid</a>
				<a href="policy" class="policy" >Политика конфиденциальности</a> -->
				<!-- <?php $url = get_privacy_policy_url(); ?>
Нажимая на кнопку  «Зарегистрироваться», вы соглашаетесь с <a href="<?= $url ?: '#'; ?>" target="_blank">политикой конфиденциальности</a>. -->
				</div>
			
		</div>
			<!-- </diva> -->
		<!-- </div> -->
	</div>
	</div>
</footer>
		<?php
			wp_footer();
		?>
	</body>
</html>