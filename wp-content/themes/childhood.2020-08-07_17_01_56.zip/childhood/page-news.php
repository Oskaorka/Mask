<?php
/*
Template Name: О короновирусе
*/

?>

<?php
    get_header();
?>
<div class="room">
	


	
<div class="container">
<div class="newstime">
<h1 class="newstimes-1_title"><?php the_field('newstimes-1'); ?>
	<p class="newstimes-1_descr">
		<?php the_field('newstimes-1_descr_about'); ?><a  href="<?php the_field('newstimes-1_descr_link'); ?>"><?php echo do_shortcode(''); ?><?php the_field('newstimes-1_descr_link_word'); ?></a>
	</p>
</h1> 

<h1 class="newstimes-2_title"><?php the_field('newstimes-2'); ?>
	<p class="newstimes-2_descr">
	<?php the_field('newstimes-2_descr_about'); ?><a  href="<?php the_field('newstimes-2_descr_link'); ?>"><?php echo do_shortcode(''); ?><?php the_field('newstimes-2_descr_link_word'); ?></a>
	</p>
</h1>

<h1 class="newstimes-3_title"><?php the_field('newstimes-3'); ?>
	<p class="newstimes-3_descr">
	<?php the_field('newstimes-3_descr_about'); ?><a  href="<?php the_field('newstimes-3_descr_link'); ?>"><?php echo do_shortcode(''); ?><?php the_field('newstimes-3_descr_link_word'); ?></a>
	</p>
</h1>

	</div>
</div>
<?php
    get_footer();
?>    